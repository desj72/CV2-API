// const subscriberNumber =  document.querySelector("#subscriber");
// const viewsNumber =  document.querySelector("#views");
// const videosNumber =  document.querySelector("#videos");
// const projectNumber =  document.querySelector("#project1");


// const apikey = "AIzaSyCkDPTJ3po7Jf0JRzJvKUs4wG_JCVcIg3k"
// const userchanel = "UC-CMamnnM2bBR9yzA-L_Rag"
// const userGithub = "desj72"

// document.addEventListener("DOMContentLoaded" , () => {
//     LoadStats();
// })

// function LoadStats () {
//     Promise.all ([
//         fetch(`https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${userchanel}&key=${apikey}`)
//         .then (response => response.json()),
//         fetch(`https://api.github.com/users/${userGithub}`)
//         .then (response => response.json())
//     ]) .then (([youtubeData, GitHubData]) => {
       

//         const{subscriberCount, videoCount, viewCount} = youtubeData.items[0].statistics;
        
//         subscriberNumber.textContent = parseInt (subscriberCount).toLocaleString;
//         viewsNumber.textContent = parseInt (viewCount).toLocaleString;
//         videosNumber.textContent = videoCount;

//         ///////////////

//         projectNumber.textContent = GitHubData.public_repos;
        
        


//     })
// }